
<footer class="footer p-3 text-white text-center">
    <div class="container">
        <a href="/privacy-policy" class="text-white text-decoration-none">Политика конфиденциальности</a> | 
        <a href="/terms-of-use" class="text-white text-decoration-none">Условия использования</a> | 
        <a href="/feedback" class="text-white text-decoration-none">Обратная связь</a>
        <p class="small mt-1">
            © <?php echo date('Y'); ?> Pro Website Management CMS. Все права защищены. <br><a href="/page/help" class="text-white text-decoration-none">Справка</a>
        </p>
    </div>
</footer>
</html>