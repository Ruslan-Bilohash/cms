<?php
// templates/default/booking_order.php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/db.php';

// Логирование для отладки
function logDebug($message) {
    error_log("[booking_order] " . $message . "\n", 3, $_SERVER['DOCUMENT_ROOT'] . '/logs/booking_debug.log');
}

// Загрузка настроек
$settings_file = $_SERVER['DOCUMENT_ROOT'] . '/uploads/booking_settings.php';
$settings = file_exists($settings_file) ? include $settings_file : [
    'currency' => 'UAH',
    'min_price' => 50,
    'max_price' => 5000
];
$currency = $settings['currency'];

// Получение данных о номере
$room_id = (int)($_GET['room_id'] ?? 0);
$stmt = $conn->prepare("SELECT r.*, c.name AS category_name FROM rooms r LEFT JOIN booking_categories c ON r.category_id = c.id WHERE r.id = ?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$room) {
    die("Номер не найден.");
}

// Обработка бронирования
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';
    $guests = (int)($_POST['guests'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    // Валидация
    $check_in_date = DateTime::createFromFormat('Y-m-d', $check_in);
    $check_out_date = DateTime::createFromFormat('Y-m-d', $check_out);
    if (!$check_in_date || !$check_out_date || $check_out_date <= $check_in_date) {
        $message = "Ошибка: Неверные даты заезда или выезда.";
    } elseif ($guests > $room['capacity']) {
        $message = "Ошибка: Количество гостей превышает вместимость номера.";
    } elseif (empty($name)) {
        $message = "Ошибка: Укажите ваше имя.";
    } elseif (empty($phone) || !preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
        $message = "Ошибка: Укажите корректный номер телефона.";
    } else {
        $stmt = $conn->prepare("INSERT INTO bookings (room_id, check_in, check_out, guests, name, phone, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("ississ", $room_id, $check_in, $check_out, $guests, $name, $phone);
        if ($stmt->execute()) {
            $message = "Бронирование успешно отправлено! Ожидайте подтверждения.";
        } else {
            $message = "Ошибка при бронировании: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Функция для получения массива изображений
function getImages($imageJson) {
    $defaultImage = ['/uploads/booking/default_room.webp'];
    if (empty($imageJson)) return $defaultImage;
    $images = json_decode($imageJson, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($images) || empty($images)) return $defaultImage;
    $validImages = array_filter($images, function($path) {
        return strpos($path, '/uploads/booking/') === 0 && file_exists($_SERVER['DOCUMENT_ROOT'] . $path);
    });
    return !empty($validImages) ? $validImages : $defaultImage;
}

// Получение 5 свободных номеров
$free_rooms = $conn->query("SELECT * FROM rooms WHERE status = 'available' AND id != $room_id LIMIT 5")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Оформление бронирования</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #003580;
            --secondary-color: #febb02;
            --success-color: #0071c2;
            --text-color: #333;
            --error-color: #721c24;
            --error-bg: #f8d7da;
            --success-bg: #e6f4ea;
            --success-text: #155724;
        }
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: var(--text-color);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: var(--primary-color);
            color: white;
            padding: 2rem;
            text-align: center;
            border-radius: 0 0 15px 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .booking-form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
        }
        .form-group {
            margin-bottom: 15px;
            position: relative;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-group i {
            position: absolute;
            left: 10px;
            top: 35px;
            color: var(--primary-color);
        }
        .btn {
            padding: 12px 20px;
            background: var(--success-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #005ea6;
        }
        .room-details {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .rooms-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .room-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .room-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .room-info {
            padding: 15px;
        }
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success {
            background: var(--success-bg);
            color: var(--success-text);
        }
        .alert-error {
            background: var(--error-bg);
            color: var(--error-color);
        }
        .room-gallery {
            position: relative;
            width: 300px;
            height: 200px;
            overflow: hidden;
        }
        .gallery-main {
            width: 100%;
            height: 100%;
        }
        .gallery-main img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
            border-radius: 10px;
        }
        .gallery-main img.active {
            display: block;
        }
        .gallery-nav {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
            opacity: 0;
            transition: opacity 0.3s;
        }
        .room-gallery:hover .gallery-nav {
            opacity: 1;
        }
        .gallery-nav button {
            background: rgba(0, 0, 0, 0.5);
            border: none;
            color: white;
            font-size: 1.2rem;
            padding: 10px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .gallery-nav button:hover {
            background: rgba(0, 0, 0, 0.8);
        }
        .gallery-thumbs-container {
            position: relative;
            width: 100%;
            margin-top: 10px;
        }
        .gallery-thumbs {
            display: flex;
            gap: 5px;
            overflow: hidden;
            width: 100%;
            scroll-behavior: smooth;
        }
        .gallery-thumbs img {
            width: calc(25% - 5px);
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
            cursor: pointer;
            opacity: 0.7;
            transition: opacity 0.3s, transform 0.3s;
        }
        .gallery-thumbs img:hover {
            opacity: 1;
            transform: scale(1.05);
        }
        .gallery-thumbs img.active {
            opacity: 1;
            border: 2px solid var(--primary-color);
        }
        .thumbs-nav {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
            pointer-events: none;
        }
        .thumbs-nav button {
            background: rgba(0, 0, 0, 0.5);
            border: none;
            color: white;
            font-size: 1rem;
            padding: 5px 10px;
            cursor: pointer;
            pointer-events: auto;
            transition: background 0.3s;
        }
        .thumbs-nav button:hover {
            background: rgba(0, 0, 0, 0.8);
        }
        .thumbs-nav button:disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }
        @media (max-width: 768px) {
            .room-details {
                flex-direction: column;
            }
            .room-gallery {
                width: 100%;
                height: 150px;
            }
            .gallery-thumbs img {
                width: calc(25% - 5px);
                height: 50px;
            }
            .rooms-list {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const gallery = document.querySelector('.room-gallery');
            const mainImages = gallery.querySelectorAll('.gallery-main img');
            const thumbsContainer = gallery.querySelector('.gallery-thumbs');
            const thumbs = gallery.querySelectorAll('.gallery-thumbs img');
            const prevMainBtn = gallery.querySelector('.gallery-nav .prev');
            const nextMainBtn = gallery.querySelector('.gallery-nav .next');
            const prevThumbsBtn = gallery.querySelector('.thumbs-nav .prev');
            const nextThumbsBtn = gallery.querySelector('.thumbs-nav .next');
            let currentIndex = 0;
            const thumbsPerPage = 4;
            let thumbsOffset = 0;

            if (mainImages.length === 0) return;

            function updateGallery(index) {
                mainImages.forEach(img => img.classList.remove('active'));
                thumbs.forEach(thumb => thumb.classList.remove('active'));
                mainImages[index].classList.add('active');
                thumbs[index].classList.add('active');
                currentIndex = index;

                const thumbWidth = thumbs[0].offsetWidth + 5;
                const visibleStart = thumbsOffset * thumbWidth;
                const visibleEnd = visibleStart + (thumbsPerPage * thumbWidth);
                const currentPosition = index * thumbWidth;
                if (currentPosition < visibleStart) {
                    thumbsOffset = index;
                } else if (currentPosition >= visibleEnd) {
                    thumbsOffset = index - thumbsPerPage + 1;
                }
                thumbsContainer.scrollLeft = thumbsOffset * thumbWidth;
                updateThumbsNav();
            }

            function updateThumbsNav() {
                prevThumbsBtn.disabled = thumbsOffset === 0;
                nextThumbsBtn.disabled = thumbsOffset + thumbsPerPage >= thumbs.length;
            }

            thumbs.forEach((thumb, index) => {
                thumb.addEventListener('click', () => updateGallery(index));
            });

            if (prevMainBtn) {
                prevMainBtn.addEventListener('click', () => {
                    let newIndex = currentIndex - 1;
                    if (newIndex < 0) newIndex = mainImages.length - 1;
                    updateGallery(newIndex);
                });
            }

            if (nextMainBtn) {
                nextMainBtn.addEventListener('click', () => {
                    let newIndex = currentIndex + 1;
                    if (newIndex >= mainImages.length) newIndex = 0;
                    updateGallery(newIndex);
                });
            }

            if (prevThumbsBtn) {
                prevThumbsBtn.addEventListener('click', () => {
                    if (thumbsOffset > 0) {
                        thumbsOffset--;
                        thumbsContainer.scrollLeft = thumbsOffset * (thumbs[0].offsetWidth + 5);
                        updateThumbsNav();
                    }
                });
            }

            if (nextThumbsBtn) {
                nextThumbsBtn.addEventListener('click', () => {
                    if (thumbsOffset + thumbsPerPage < thumbs.length) {
                        thumbsOffset++;
                        thumbsContainer.scrollLeft = thumbsOffset * (thumbs[0].offsetWidth + 5);
                        updateThumbsNav();
                    }
                });
            }

            updateGallery(0);
        });
    </script>
</head>
<body>
    <div class="header">
        <h1><i class="fas fa-calendar-check"></i> Оформление бронирования</h1>
        <p>Забронируйте ваше проживание</p>
    </div>
    <div class="container">
        <?php if (isset($message)): ?>
            <div class="alert <?php echo strpos($message, 'Ошибка') === false ? 'alert-success' : 'alert-error'; ?>">
                <i class="fas <?php echo strpos($message, 'Ошибка') === false ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i> <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="room-details">
            <div class="room-gallery">
                <div class="gallery-main">
                    <?php foreach (getImages($room['image']) as $index => $image): ?>
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($room['name']); ?>" class="<?php echo $index === 0 ? 'active' : ''; ?>">
                    <?php endforeach; ?>
                </div>
                <div class="gallery-nav">
                    <button class="prev"><i class="fas fa-chevron-left"></i></button>
                    <button class="next"><i class="fas fa-chevron-right"></i></button>
                </div>
                <div class="gallery-thumbs-container">
                    <div class="gallery-thumbs">
                        <?php foreach (getImages($room['image']) as $index => $image): ?>
                            <img src="<?php echo htmlspecialchars($image); ?>" alt="Thumbnail" class="<?php echo $index === 0 ? 'active' : ''; ?>">
                        <?php endforeach; ?>
                    </div>
                    <?php if (count(getImages($room['image'])) > 4): ?>
                        <div class="thumbs-nav">
                            <button class="prev"><i class="fas fa-chevron-left"></i></button>
                            <button class="next"><i class="fas fa-chevron-right"></i></button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <h2><?php echo htmlspecialchars($room['name']); ?></h2>
                <p><i class="fas fa-folder"></i> Категория: <?php echo htmlspecialchars($room['category_name']); ?></p>
                <p><i class="fas fa-users"></i> Вместимость: <?php echo htmlspecialchars($room['capacity']); ?> гостей</p>
                <p><i class="fas fa-money-bill-wave"></i> Цена: <?php echo htmlspecialchars($room['price']); ?> <?php echo htmlspecialchars($currency); ?>/ночь</p>
            </div>
        </div>

        <div class="booking-form">
            <h3><i class="fas fa-edit"></i> Ваши данные</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Имя:</label>
                    <i class="fas fa-user"></i>
                    <input type="text" name="name" placeholder="Введите ваше имя" required>
                </div>
                <div class="form-group">
                    <label>Телефон:</label>
                    <i class="fas fa-phone"></i>
                    <input type="tel" name="phone" placeholder="+380123456789" pattern="\+?[0-9]{10,15}" required>
                </div>
                <div class="form-group">
                    <label>Дата заезда:</label>
                    <i class="fas fa-calendar-day"></i>
                    <input type="date" name="check_in" required>
                </div>
                <div class="form-group">
                    <label>Дата выезда:</label>
                    <i class="fas fa-calendar-day"></i>
                    <input type="date" name="check_out" required>
                </div>
                <div class="form-group">
                    <label>Количество гостей:</label>
                    <i class="fas fa-users"></i>
                    <select name="guests" required>
                        <?php for ($i = 1; $i <= $room['capacity']; $i++): ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?> <?php echo $i == 1 ? 'гость' : 'гостей'; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <button type="submit" class="btn"><i class="fas fa-calendar-check"></i> Забронировать</button>
            </form>
        </div>

        <div>
            <h3><i class="fas fa-hotel"></i> Другие доступные номера</h3>
            <div class="rooms-list">
                <?php foreach ($free_rooms as $free_room): ?>
                    <div class="room-card">
                        <img src="<?php echo htmlspecialchars(getImages($free_room['image'])[0]); ?>" alt="<?php echo htmlspecialchars($free_room['name']); ?>">
                        <div class="room-info">
                            <h3><?php echo htmlspecialchars($free_room['name']); ?></h3>
                            <p><i class="fas fa-users"></i> До <?php echo htmlspecialchars($free_room['capacity']); ?> гостей</p>
                            <p><i class="fas fa-money-bill-wave"></i> <?php echo htmlspecialchars($free_room['price']); ?> <?php echo htmlspecialchars($currency); ?>/ночь</p>
                            <a href="/templates/default/booking_order.php?room_id=<?php echo $free_room['id']; ?>" class="btn"><i class="fas fa-calendar-check"></i> Забронировать</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php include 'booking_footer.php'; ?>
</body>
</html>